package com.coffe.maker.components;

public interface Button {

    void press();

    boolean isPressed();
}
