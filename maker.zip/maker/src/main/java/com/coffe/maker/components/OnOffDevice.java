package com.coffe.maker.components;

public interface OnOffDevice {
    void on();
    void off();
    boolean isOn();

}
