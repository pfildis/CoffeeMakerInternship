package com.coffe.maker.controller;

public enum Status {
    OFF, BREWING, WAITING, DONE, TAKE
}
